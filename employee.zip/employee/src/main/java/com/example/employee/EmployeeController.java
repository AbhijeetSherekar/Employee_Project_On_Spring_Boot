package com.example.employee;

import java.util.ArrayList;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.employee.dao.EmployeeInterface;
import com.example.employee.entity.Employee;




@Controller
public class EmployeeController {
    Scanner sc=new Scanner(System.in);
    @Autowired
    EmployeeInterface employeeinterface;
    ArrayList<Employee> emp=new ArrayList<Employee>();
   
    @RequestMapping("/empdata")  
    public Object insert(Employee employee)
    {
    	System.out.println(" For Data Insert");
		
		for(int i=0;i<2;i++)
		{
			Employee emp1=new Employee();
			System.out.println("Enter Employee id: :");
			emp1.setId(sc.nextInt());
			System.out.println("Enter Employee Name: :");
			emp1.setName(sc.next());
			System.out.println("Enter Employee Department Name: :");
			emp1.setDept(sc.next());
			employeeinterface.insert(emp1);
			emp.add(emp1);
			
		}		
	   emp=	employeeinterface.select();
	   
		for(int x=0; x<emp.size();x++) {
			 Employee emp2=emp.get(x);
			 
			System.out.println(" Employee id: :"+emp2.getId());
			System.out.println("Employee NAme: :"+emp2.getName());
			System.out.println("Employee Department No: :"+emp2.getDept());
		}
		
		
		/*
		 * System.out.println("Enter Employee Id: :"); int id=sc.nextInt(); for(int i=0;
		 * i<emp.size(); i++) { Employee e=emp.get(i); if(emp.get(i).getId()==id) {
		 * System.out.println("Enter new Employee Name: :"); e.setName(sc.next());
		 * System.out.println("Enter New Employee Mobile Mobile: : ");
		 * e.setMobileNum(sc.nextLong()); System.out.println("Enter Dept Name: :");
		 * e.setDept(sc.next()); employeeinterface.update(e);
		 * 
		 * 
		 * System.out.println("ID Of Employee: :"+e.getId());
		 * System.out.println("new Name of Employee: :"+e.getName());
		 * System.out.println("Mobile No "+e.getMobileNum());
		 * System.out.println("Dept : :"+e.getDept()); } }
		 * 
		 * System.out.println(" For Data Delete : :");
		 * System.out.println("Enter Employee Id: :"); int id1 =sc.nextInt();
		 * employeeinterface.delete(id1);
		 */
		return employee;
    	
    }
    
    @PutMapping("/update")
    public Object update(Employee employee)
    {
    	System.out.println("Enter Employee Id: :");
		int id=sc.nextInt();
		for(int i=0; i<emp.size(); i++)
		{
			Employee e=emp.get(i);
			if(emp.get(i).getId()==id)
			{
				System.out.println("Enter new Employee Name: :");
				 e.setName(sc.next());
				 System.out.println("Enter Dept Name: :");
				 e.setDept(sc.next());
			 	 employeeinterface.update(e);
			 	 
				 
					System.out.println("ID Of Employee: :"+e.getId());
					System.out.println("new Name of Employee: :"+e.getName());
					System.out.println("Dept : :"+e.getDept());
			}
		}
    	
		return employee;
    	
    }
    
    @DeleteMapping("/delete")
    public Object delete(Employee employee)
    {
    	 System.out.println("Enter Employee Id: :");
		 int id1 =sc.nextInt(); 
		 employeeinterface.delete(id1);
    	
		return employee;
    	
    }
    
   
	@GetMapping("/select")
	@ResponseBody
	public ArrayList<Employee> select()
	{
	System.out.println("Showing All Data Of People");
		ArrayList<Employee>emp6=new ArrayList<Employee>();
		emp6=employeeinterface.select();
		for(int y=0;y<emp6.size();y++)
		{
			Employee emp8=emp6.get(y);
			System.out.println(" Employee Id: : "+emp8.getId());
			System.out.println("Employee Name: :"+emp8.getName());
			System.out.println("Employee Dept Name: :"+emp8.getDept());
		}
		 return emp6;
	}
}
