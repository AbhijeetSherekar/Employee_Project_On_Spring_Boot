package com.example.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.employee.entity.Employee;


@Repository
public class EmployeeImplement  implements EmployeeInterface{

	@Autowired
	private DataSource datasource;
	
	String insert="insert into employe (employeId,employeName,empDept) values(?,?,?)";
	String select="select * from employee";
	String update="update employee set name=? ,mobileNum=?,dept=? where id=?";
	String delete="DELETE FROM employee WHERE id=?";
	
	public void setDataSource(DataSource datasource)
	{
		this.datasource=datasource;
		
	}
	
	//Data Inserting
	@Override
	public void insert(Employee employee)
	{
		Connection conn=null;
		try {
			conn=datasource.getConnection();
			PreparedStatement ps=conn.prepareStatement(insert);
			 
			ps.setInt(1, employee.getId());
			ps.setString(2, employee.getName());
			ps.setString(3, employee.getDept());
			ps.executeUpdate();
			conn.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
	
	//for Data Shown
	@Override
	public ArrayList<Employee> select()
	{
		Connection con=null;
		ArrayList<Employee>emp6=new ArrayList<Employee>();
		try {
			
			con=datasource.getConnection();
			PreparedStatement ps=con.prepareStatement(select);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Employee emp5=new Employee();
				
			     emp5.setId(rs.getInt("id"));
			     emp5.setName(rs.getString("name"));
			     emp5.setDept(rs.getString("dept"));
			     
			     emp6.add(emp5);
			         
			}
			con.close();
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return emp6;
	}
	
	//For Data Update
	@Override
	public void update(Employee employee)
	{
	
		
		try {
			Connection con=null;
			Employee emp7=new Employee();
			
			con =datasource.getConnection();
			PreparedStatement ps=con.prepareStatement(update);
			ps.setInt(1,employee.getId());
	    	ps.setString(2, employee.getName());
			ps.setString(3,employee.getDept());
			ps.executeUpdate();
			con.close();
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	//Data Delete
	@Override
	public void delete(int id)
	{
		Connection con=null;
		try {
			con=datasource.getConnection();
			PreparedStatement ps=con.prepareStatement(delete);
			ps.setInt(1,id);
			ps.executeUpdate();
			con.close();
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
