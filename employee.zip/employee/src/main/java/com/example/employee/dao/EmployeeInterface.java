package com.example.employee.dao;

import java.util.ArrayList;

import com.example.employee.entity.Employee;

public interface EmployeeInterface {

	void insert(Employee employee);

	ArrayList<Employee> select();

	
	void update(Employee employee);

	void delete(int id);

	

}
